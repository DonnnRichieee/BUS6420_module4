# Load the necessary packages
library(png)
library(grid)

# Load the image file generated in Python
img <- readPNG("C:/Users/Adeitan Richard/Documents/module_4/ratings_dist.png")


# Display the image in R
grid.raster(img)

