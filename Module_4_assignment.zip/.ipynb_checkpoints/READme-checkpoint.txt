# Nexflix Data Visualization

This is a Python program used to clean and visualize the nexflix data set.

## Getting Started

Follow these instructions to get a copy of the project up and running on your local machine.

### Prerequisites

- Python 3.x
- Jupyter Notebook (optional)
- R or Rstudio

### Usage

The project consists of several files:

- `Nexflix_analysis.ipynb`: Contains the majority of the code analysis.
- `Nexflix_shows_movies`: Contains the unzipped dataset 
- `nexflix_data.zip`: Contains the zip file
- `ratings_dist.png`: Contains the image integrated into R.
- `ratings_dist.R`: Contains the R code used to display the imported chart.


### Instructions

- Open the `Nexflix_analysis.ipynb` file

- Unzip the zipped netflix data set 
- Rename the file to `Nexflix_shows_movies`
- Read the csv file and drop missing values to aid correct representation of the data
- Display the first 10 rows
- Explore some descriptive analysis on the data (mean, standard deviation, etc)
- Get some info about the data, in terms of how many columns and data entry rows
- Visualize the most watched genre using seaborn and plotly libraries
- Visualize ratings distribution using seaborn and plotly libraries
- Save the distribution of ratings on netflix and name it `ratings_dist.png`
- Open the R script name `ratings_dist.R`
- Load the necessary packages `png` and `grid`
- Load the image file path generated in python
- Note: Edit the path in reference to your computer
- Finally, display the chart in R



